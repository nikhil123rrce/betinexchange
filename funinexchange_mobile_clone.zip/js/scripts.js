document.addEventListener('DOMContentLoaded', () => {
  const menuToggle = document.getElementById('menu-toggle');
  const navMenu = document.getElementById('nav-menu');

  menuToggle.addEventListener('click', () => {
    navMenu.style.display = (navMenu.style.display === 'block') ? 'none' : 'block';
  });

  document.getElementById('login-form').addEventListener('submit', e => {
    e.preventDefault();
    alert('Login submitted: ' + document.querySelector('[name="username"]').value);
  });
});
